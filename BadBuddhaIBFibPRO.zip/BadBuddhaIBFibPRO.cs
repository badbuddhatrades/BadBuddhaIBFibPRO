#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private BadBuddhaIBFibPRO[] cacheBadBuddhaIBFibPRO;

		
		public BadBuddhaIBFibPRO BadBuddhaIBFibPRO(bool debugEnabled, bool debugLogTab, bool enableUpdateCheck, bool showUpdatePopup, bool showIBRectangle, bool showMidline, bool showLabels, Stroke iBStroke, Stroke midStroke, Stroke extUpStroke, Stroke extDownStroke, Brush rectFillBrush, int rectFillOpacityPct, Brush labelBrush, string labelFontName, int labelFontSize, bool showLiveDuringIB, string levelsCsv, bool block1_Enabled, bool block1_UseFixedStart, string block1_FixedStart, int block1_StartOffsetMinutes, int block1_LengthMinutes, bool block1_AnchorToCalendarDay, bool block1_ExtendToSessionEnd, bool block2_Enabled, bool block2_UseFixedStart, string block2_FixedStart, int block2_StartOffsetMinutes, int block2_LengthMinutes, bool block2_AnchorToCalendarDay, bool block2_ExtendToSessionEnd, bool block3_Enabled, bool block3_UseFixedStart, string block3_FixedStart, int block3_StartOffsetMinutes, int block3_LengthMinutes, bool block3_AnchorToCalendarDay, bool block3_ExtendToSessionEnd, bool block4_Enabled, bool block4_UseFixedStart, string block4_FixedStart, int block4_StartOffsetMinutes, int block4_LengthMinutes, bool block4_AnchorToCalendarDay, bool block4_ExtendToSessionEnd)
		{
			return BadBuddhaIBFibPRO(Input, debugEnabled, debugLogTab, enableUpdateCheck, showUpdatePopup, showIBRectangle, showMidline, showLabels, iBStroke, midStroke, extUpStroke, extDownStroke, rectFillBrush, rectFillOpacityPct, labelBrush, labelFontName, labelFontSize, showLiveDuringIB, levelsCsv, block1_Enabled, block1_UseFixedStart, block1_FixedStart, block1_StartOffsetMinutes, block1_LengthMinutes, block1_AnchorToCalendarDay, block1_ExtendToSessionEnd, block2_Enabled, block2_UseFixedStart, block2_FixedStart, block2_StartOffsetMinutes, block2_LengthMinutes, block2_AnchorToCalendarDay, block2_ExtendToSessionEnd, block3_Enabled, block3_UseFixedStart, block3_FixedStart, block3_StartOffsetMinutes, block3_LengthMinutes, block3_AnchorToCalendarDay, block3_ExtendToSessionEnd, block4_Enabled, block4_UseFixedStart, block4_FixedStart, block4_StartOffsetMinutes, block4_LengthMinutes, block4_AnchorToCalendarDay, block4_ExtendToSessionEnd);
		}


		
		public BadBuddhaIBFibPRO BadBuddhaIBFibPRO(ISeries<double> input, bool debugEnabled, bool debugLogTab, bool enableUpdateCheck, bool showUpdatePopup, bool showIBRectangle, bool showMidline, bool showLabels, Stroke iBStroke, Stroke midStroke, Stroke extUpStroke, Stroke extDownStroke, Brush rectFillBrush, int rectFillOpacityPct, Brush labelBrush, string labelFontName, int labelFontSize, bool showLiveDuringIB, string levelsCsv, bool block1_Enabled, bool block1_UseFixedStart, string block1_FixedStart, int block1_StartOffsetMinutes, int block1_LengthMinutes, bool block1_AnchorToCalendarDay, bool block1_ExtendToSessionEnd, bool block2_Enabled, bool block2_UseFixedStart, string block2_FixedStart, int block2_StartOffsetMinutes, int block2_LengthMinutes, bool block2_AnchorToCalendarDay, bool block2_ExtendToSessionEnd, bool block3_Enabled, bool block3_UseFixedStart, string block3_FixedStart, int block3_StartOffsetMinutes, int block3_LengthMinutes, bool block3_AnchorToCalendarDay, bool block3_ExtendToSessionEnd, bool block4_Enabled, bool block4_UseFixedStart, string block4_FixedStart, int block4_StartOffsetMinutes, int block4_LengthMinutes, bool block4_AnchorToCalendarDay, bool block4_ExtendToSessionEnd)
		{
			if (cacheBadBuddhaIBFibPRO != null)
				for (int idx = 0; idx < cacheBadBuddhaIBFibPRO.Length; idx++)
					if (cacheBadBuddhaIBFibPRO[idx].DebugEnabled == debugEnabled && cacheBadBuddhaIBFibPRO[idx].DebugLogTab == debugLogTab && cacheBadBuddhaIBFibPRO[idx].EnableUpdateCheck == enableUpdateCheck && cacheBadBuddhaIBFibPRO[idx].ShowUpdatePopup == showUpdatePopup && cacheBadBuddhaIBFibPRO[idx].ShowIBRectangle == showIBRectangle && cacheBadBuddhaIBFibPRO[idx].ShowMidline == showMidline && cacheBadBuddhaIBFibPRO[idx].ShowLabels == showLabels && cacheBadBuddhaIBFibPRO[idx].IBStroke == iBStroke && cacheBadBuddhaIBFibPRO[idx].MidStroke == midStroke && cacheBadBuddhaIBFibPRO[idx].ExtUpStroke == extUpStroke && cacheBadBuddhaIBFibPRO[idx].ExtDownStroke == extDownStroke && cacheBadBuddhaIBFibPRO[idx].RectFillBrush == rectFillBrush && cacheBadBuddhaIBFibPRO[idx].RectFillOpacityPct == rectFillOpacityPct && cacheBadBuddhaIBFibPRO[idx].LabelBrush == labelBrush && cacheBadBuddhaIBFibPRO[idx].LabelFontName == labelFontName && cacheBadBuddhaIBFibPRO[idx].LabelFontSize == labelFontSize && cacheBadBuddhaIBFibPRO[idx].ShowLiveDuringIB == showLiveDuringIB && cacheBadBuddhaIBFibPRO[idx].LevelsCsv == levelsCsv && cacheBadBuddhaIBFibPRO[idx].Block1_Enabled == block1_Enabled && cacheBadBuddhaIBFibPRO[idx].Block1_UseFixedStart == block1_UseFixedStart && cacheBadBuddhaIBFibPRO[idx].Block1_FixedStart == block1_FixedStart && cacheBadBuddhaIBFibPRO[idx].Block1_StartOffsetMinutes == block1_StartOffsetMinutes && cacheBadBuddhaIBFibPRO[idx].Block1_LengthMinutes == block1_LengthMinutes && cacheBadBuddhaIBFibPRO[idx].Block1_AnchorToCalendarDay == block1_AnchorToCalendarDay && cacheBadBuddhaIBFibPRO[idx].Block1_ExtendToSessionEnd == block1_ExtendToSessionEnd && cacheBadBuddhaIBFibPRO[idx].Block2_Enabled == block2_Enabled && cacheBadBuddhaIBFibPRO[idx].Block2_UseFixedStart == block2_UseFixedStart && cacheBadBuddhaIBFibPRO[idx].Block2_FixedStart == block2_FixedStart && cacheBadBuddhaIBFibPRO[idx].Block2_StartOffsetMinutes == block2_StartOffsetMinutes && cacheBadBuddhaIBFibPRO[idx].Block2_LengthMinutes == block2_LengthMinutes && cacheBadBuddhaIBFibPRO[idx].Block2_AnchorToCalendarDay == block2_AnchorToCalendarDay && cacheBadBuddhaIBFibPRO[idx].Block2_ExtendToSessionEnd == block2_ExtendToSessionEnd && cacheBadBuddhaIBFibPRO[idx].Block3_Enabled == block3_Enabled && cacheBadBuddhaIBFibPRO[idx].Block3_UseFixedStart == block3_UseFixedStart && cacheBadBuddhaIBFibPRO[idx].Block3_FixedStart == block3_FixedStart && cacheBadBuddhaIBFibPRO[idx].Block3_StartOffsetMinutes == block3_StartOffsetMinutes && cacheBadBuddhaIBFibPRO[idx].Block3_LengthMinutes == block3_LengthMinutes && cacheBadBuddhaIBFibPRO[idx].Block3_AnchorToCalendarDay == block3_AnchorToCalendarDay && cacheBadBuddhaIBFibPRO[idx].Block3_ExtendToSessionEnd == block3_ExtendToSessionEnd && cacheBadBuddhaIBFibPRO[idx].Block4_Enabled == block4_Enabled && cacheBadBuddhaIBFibPRO[idx].Block4_UseFixedStart == block4_UseFixedStart && cacheBadBuddhaIBFibPRO[idx].Block4_FixedStart == block4_FixedStart && cacheBadBuddhaIBFibPRO[idx].Block4_StartOffsetMinutes == block4_StartOffsetMinutes && cacheBadBuddhaIBFibPRO[idx].Block4_LengthMinutes == block4_LengthMinutes && cacheBadBuddhaIBFibPRO[idx].Block4_AnchorToCalendarDay == block4_AnchorToCalendarDay && cacheBadBuddhaIBFibPRO[idx].Block4_ExtendToSessionEnd == block4_ExtendToSessionEnd && cacheBadBuddhaIBFibPRO[idx].EqualsInput(input))
						return cacheBadBuddhaIBFibPRO[idx];
			return CacheIndicator<BadBuddhaIBFibPRO>(new BadBuddhaIBFibPRO(){ DebugEnabled = debugEnabled, DebugLogTab = debugLogTab, EnableUpdateCheck = enableUpdateCheck, ShowUpdatePopup = showUpdatePopup, ShowIBRectangle = showIBRectangle, ShowMidline = showMidline, ShowLabels = showLabels, IBStroke = iBStroke, MidStroke = midStroke, ExtUpStroke = extUpStroke, ExtDownStroke = extDownStroke, RectFillBrush = rectFillBrush, RectFillOpacityPct = rectFillOpacityPct, LabelBrush = labelBrush, LabelFontName = labelFontName, LabelFontSize = labelFontSize, ShowLiveDuringIB = showLiveDuringIB, LevelsCsv = levelsCsv, Block1_Enabled = block1_Enabled, Block1_UseFixedStart = block1_UseFixedStart, Block1_FixedStart = block1_FixedStart, Block1_StartOffsetMinutes = block1_StartOffsetMinutes, Block1_LengthMinutes = block1_LengthMinutes, Block1_AnchorToCalendarDay = block1_AnchorToCalendarDay, Block1_ExtendToSessionEnd = block1_ExtendToSessionEnd, Block2_Enabled = block2_Enabled, Block2_UseFixedStart = block2_UseFixedStart, Block2_FixedStart = block2_FixedStart, Block2_StartOffsetMinutes = block2_StartOffsetMinutes, Block2_LengthMinutes = block2_LengthMinutes, Block2_AnchorToCalendarDay = block2_AnchorToCalendarDay, Block2_ExtendToSessionEnd = block2_ExtendToSessionEnd, Block3_Enabled = block3_Enabled, Block3_UseFixedStart = block3_UseFixedStart, Block3_FixedStart = block3_FixedStart, Block3_StartOffsetMinutes = block3_StartOffsetMinutes, Block3_LengthMinutes = block3_LengthMinutes, Block3_AnchorToCalendarDay = block3_AnchorToCalendarDay, Block3_ExtendToSessionEnd = block3_ExtendToSessionEnd, Block4_Enabled = block4_Enabled, Block4_UseFixedStart = block4_UseFixedStart, Block4_FixedStart = block4_FixedStart, Block4_StartOffsetMinutes = block4_StartOffsetMinutes, Block4_LengthMinutes = block4_LengthMinutes, Block4_AnchorToCalendarDay = block4_AnchorToCalendarDay, Block4_ExtendToSessionEnd = block4_ExtendToSessionEnd }, input, ref cacheBadBuddhaIBFibPRO);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.BadBuddhaIBFibPRO BadBuddhaIBFibPRO(bool debugEnabled, bool debugLogTab, bool enableUpdateCheck, bool showUpdatePopup, bool showIBRectangle, bool showMidline, bool showLabels, Stroke iBStroke, Stroke midStroke, Stroke extUpStroke, Stroke extDownStroke, Brush rectFillBrush, int rectFillOpacityPct, Brush labelBrush, string labelFontName, int labelFontSize, bool showLiveDuringIB, string levelsCsv, bool block1_Enabled, bool block1_UseFixedStart, string block1_FixedStart, int block1_StartOffsetMinutes, int block1_LengthMinutes, bool block1_AnchorToCalendarDay, bool block1_ExtendToSessionEnd, bool block2_Enabled, bool block2_UseFixedStart, string block2_FixedStart, int block2_StartOffsetMinutes, int block2_LengthMinutes, bool block2_AnchorToCalendarDay, bool block2_ExtendToSessionEnd, bool block3_Enabled, bool block3_UseFixedStart, string block3_FixedStart, int block3_StartOffsetMinutes, int block3_LengthMinutes, bool block3_AnchorToCalendarDay, bool block3_ExtendToSessionEnd, bool block4_Enabled, bool block4_UseFixedStart, string block4_FixedStart, int block4_StartOffsetMinutes, int block4_LengthMinutes, bool block4_AnchorToCalendarDay, bool block4_ExtendToSessionEnd)
		{
			return indicator.BadBuddhaIBFibPRO(Input, debugEnabled, debugLogTab, enableUpdateCheck, showUpdatePopup, showIBRectangle, showMidline, showLabels, iBStroke, midStroke, extUpStroke, extDownStroke, rectFillBrush, rectFillOpacityPct, labelBrush, labelFontName, labelFontSize, showLiveDuringIB, levelsCsv, block1_Enabled, block1_UseFixedStart, block1_FixedStart, block1_StartOffsetMinutes, block1_LengthMinutes, block1_AnchorToCalendarDay, block1_ExtendToSessionEnd, block2_Enabled, block2_UseFixedStart, block2_FixedStart, block2_StartOffsetMinutes, block2_LengthMinutes, block2_AnchorToCalendarDay, block2_ExtendToSessionEnd, block3_Enabled, block3_UseFixedStart, block3_FixedStart, block3_StartOffsetMinutes, block3_LengthMinutes, block3_AnchorToCalendarDay, block3_ExtendToSessionEnd, block4_Enabled, block4_UseFixedStart, block4_FixedStart, block4_StartOffsetMinutes, block4_LengthMinutes, block4_AnchorToCalendarDay, block4_ExtendToSessionEnd);
		}


		
		public Indicators.BadBuddhaIBFibPRO BadBuddhaIBFibPRO(ISeries<double> input , bool debugEnabled, bool debugLogTab, bool enableUpdateCheck, bool showUpdatePopup, bool showIBRectangle, bool showMidline, bool showLabels, Stroke iBStroke, Stroke midStroke, Stroke extUpStroke, Stroke extDownStroke, Brush rectFillBrush, int rectFillOpacityPct, Brush labelBrush, string labelFontName, int labelFontSize, bool showLiveDuringIB, string levelsCsv, bool block1_Enabled, bool block1_UseFixedStart, string block1_FixedStart, int block1_StartOffsetMinutes, int block1_LengthMinutes, bool block1_AnchorToCalendarDay, bool block1_ExtendToSessionEnd, bool block2_Enabled, bool block2_UseFixedStart, string block2_FixedStart, int block2_StartOffsetMinutes, int block2_LengthMinutes, bool block2_AnchorToCalendarDay, bool block2_ExtendToSessionEnd, bool block3_Enabled, bool block3_UseFixedStart, string block3_FixedStart, int block3_StartOffsetMinutes, int block3_LengthMinutes, bool block3_AnchorToCalendarDay, bool block3_ExtendToSessionEnd, bool block4_Enabled, bool block4_UseFixedStart, string block4_FixedStart, int block4_StartOffsetMinutes, int block4_LengthMinutes, bool block4_AnchorToCalendarDay, bool block4_ExtendToSessionEnd)
		{
			return indicator.BadBuddhaIBFibPRO(input, debugEnabled, debugLogTab, enableUpdateCheck, showUpdatePopup, showIBRectangle, showMidline, showLabels, iBStroke, midStroke, extUpStroke, extDownStroke, rectFillBrush, rectFillOpacityPct, labelBrush, labelFontName, labelFontSize, showLiveDuringIB, levelsCsv, block1_Enabled, block1_UseFixedStart, block1_FixedStart, block1_StartOffsetMinutes, block1_LengthMinutes, block1_AnchorToCalendarDay, block1_ExtendToSessionEnd, block2_Enabled, block2_UseFixedStart, block2_FixedStart, block2_StartOffsetMinutes, block2_LengthMinutes, block2_AnchorToCalendarDay, block2_ExtendToSessionEnd, block3_Enabled, block3_UseFixedStart, block3_FixedStart, block3_StartOffsetMinutes, block3_LengthMinutes, block3_AnchorToCalendarDay, block3_ExtendToSessionEnd, block4_Enabled, block4_UseFixedStart, block4_FixedStart, block4_StartOffsetMinutes, block4_LengthMinutes, block4_AnchorToCalendarDay, block4_ExtendToSessionEnd);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.BadBuddhaIBFibPRO BadBuddhaIBFibPRO(bool debugEnabled, bool debugLogTab, bool enableUpdateCheck, bool showUpdatePopup, bool showIBRectangle, bool showMidline, bool showLabels, Stroke iBStroke, Stroke midStroke, Stroke extUpStroke, Stroke extDownStroke, Brush rectFillBrush, int rectFillOpacityPct, Brush labelBrush, string labelFontName, int labelFontSize, bool showLiveDuringIB, string levelsCsv, bool block1_Enabled, bool block1_UseFixedStart, string block1_FixedStart, int block1_StartOffsetMinutes, int block1_LengthMinutes, bool block1_AnchorToCalendarDay, bool block1_ExtendToSessionEnd, bool block2_Enabled, bool block2_UseFixedStart, string block2_FixedStart, int block2_StartOffsetMinutes, int block2_LengthMinutes, bool block2_AnchorToCalendarDay, bool block2_ExtendToSessionEnd, bool block3_Enabled, bool block3_UseFixedStart, string block3_FixedStart, int block3_StartOffsetMinutes, int block3_LengthMinutes, bool block3_AnchorToCalendarDay, bool block3_ExtendToSessionEnd, bool block4_Enabled, bool block4_UseFixedStart, string block4_FixedStart, int block4_StartOffsetMinutes, int block4_LengthMinutes, bool block4_AnchorToCalendarDay, bool block4_ExtendToSessionEnd)
		{
			return indicator.BadBuddhaIBFibPRO(Input, debugEnabled, debugLogTab, enableUpdateCheck, showUpdatePopup, showIBRectangle, showMidline, showLabels, iBStroke, midStroke, extUpStroke, extDownStroke, rectFillBrush, rectFillOpacityPct, labelBrush, labelFontName, labelFontSize, showLiveDuringIB, levelsCsv, block1_Enabled, block1_UseFixedStart, block1_FixedStart, block1_StartOffsetMinutes, block1_LengthMinutes, block1_AnchorToCalendarDay, block1_ExtendToSessionEnd, block2_Enabled, block2_UseFixedStart, block2_FixedStart, block2_StartOffsetMinutes, block2_LengthMinutes, block2_AnchorToCalendarDay, block2_ExtendToSessionEnd, block3_Enabled, block3_UseFixedStart, block3_FixedStart, block3_StartOffsetMinutes, block3_LengthMinutes, block3_AnchorToCalendarDay, block3_ExtendToSessionEnd, block4_Enabled, block4_UseFixedStart, block4_FixedStart, block4_StartOffsetMinutes, block4_LengthMinutes, block4_AnchorToCalendarDay, block4_ExtendToSessionEnd);
		}


		
		public Indicators.BadBuddhaIBFibPRO BadBuddhaIBFibPRO(ISeries<double> input , bool debugEnabled, bool debugLogTab, bool enableUpdateCheck, bool showUpdatePopup, bool showIBRectangle, bool showMidline, bool showLabels, Stroke iBStroke, Stroke midStroke, Stroke extUpStroke, Stroke extDownStroke, Brush rectFillBrush, int rectFillOpacityPct, Brush labelBrush, string labelFontName, int labelFontSize, bool showLiveDuringIB, string levelsCsv, bool block1_Enabled, bool block1_UseFixedStart, string block1_FixedStart, int block1_StartOffsetMinutes, int block1_LengthMinutes, bool block1_AnchorToCalendarDay, bool block1_ExtendToSessionEnd, bool block2_Enabled, bool block2_UseFixedStart, string block2_FixedStart, int block2_StartOffsetMinutes, int block2_LengthMinutes, bool block2_AnchorToCalendarDay, bool block2_ExtendToSessionEnd, bool block3_Enabled, bool block3_UseFixedStart, string block3_FixedStart, int block3_StartOffsetMinutes, int block3_LengthMinutes, bool block3_AnchorToCalendarDay, bool block3_ExtendToSessionEnd, bool block4_Enabled, bool block4_UseFixedStart, string block4_FixedStart, int block4_StartOffsetMinutes, int block4_LengthMinutes, bool block4_AnchorToCalendarDay, bool block4_ExtendToSessionEnd)
		{
			return indicator.BadBuddhaIBFibPRO(input, debugEnabled, debugLogTab, enableUpdateCheck, showUpdatePopup, showIBRectangle, showMidline, showLabels, iBStroke, midStroke, extUpStroke, extDownStroke, rectFillBrush, rectFillOpacityPct, labelBrush, labelFontName, labelFontSize, showLiveDuringIB, levelsCsv, block1_Enabled, block1_UseFixedStart, block1_FixedStart, block1_StartOffsetMinutes, block1_LengthMinutes, block1_AnchorToCalendarDay, block1_ExtendToSessionEnd, block2_Enabled, block2_UseFixedStart, block2_FixedStart, block2_StartOffsetMinutes, block2_LengthMinutes, block2_AnchorToCalendarDay, block2_ExtendToSessionEnd, block3_Enabled, block3_UseFixedStart, block3_FixedStart, block3_StartOffsetMinutes, block3_LengthMinutes, block3_AnchorToCalendarDay, block3_ExtendToSessionEnd, block4_Enabled, block4_UseFixedStart, block4_FixedStart, block4_StartOffsetMinutes, block4_LengthMinutes, block4_AnchorToCalendarDay, block4_ExtendToSessionEnd);
		}

	}
}

#endregion
